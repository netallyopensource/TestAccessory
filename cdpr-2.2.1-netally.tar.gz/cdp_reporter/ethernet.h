#ifndef __ETHERNET_H__
#define __ETHERNET_H__


// Ethernet II header
typedef struct
{
  T_MacAddr dstAddr;       // Destination MAC
  T_MacAddr  srcAddr;      // Source MAC
  T_UINT16 type;           // Ethernet Type
} T_EthIIHdr;

// Ethernet 802_3 (raw) header
typedef struct
{
  T_MacAddr dstAddr;       // Destination MAC
  T_MacAddr  srcAddr;      // Source MAC
  T_UINT16 length;         // Length of the data in the frame                         
} T_Eth802_3Hdr;

// Ethernet 802_2 header
typedef struct
{
  T_MacAddr  dstAddr;      // Destination MAC
  T_MacAddr  srcAddr;      // Source MAC
  T_UINT16 length;         // Length of the data portion                       
  T_UINT8  dsap;           // Destination SAP                       
  T_UINT8  ssap;           // Source SAP                       
  T_UINT8  control;        // Control code                       
} T_Eth802_2Hdr;

// Ethernet SNAP header
typedef struct
{                           
  T_MacAddr  dstAddr;      // Destination MAC
  T_MacAddr  srcAddr;      // Source MAC
  T_UINT16 length;         // Length of the data portion                       
  T_UINT8  dsap;           // Destination SAP                       
  T_UINT8  ssap;           // Source SAP                       
  T_UINT8  control;        // Control code                       
  T_UINT8  org[3];         // Organization code                       
  T_UINT16 type;           // Ethernet Type                       
} T_EthSnapHdr;


// Min ethernet frame is 60 (not including FCS)
enum {
  FCS_SIZE      = 4,
  QTAG_SIZE     = 4,
  SAP_CNTL      = 0x03,
  ETH_II_LEN    = 14,  // sizeof(EthIIHdrT),
  ETH_RAW_LEN   = 14,  // sizeof(Eth802_3HdrT),
  ETH_802_2_LEN = 17,  // sizeof(Eth802_2HdrT),
  ETH_SNAP_LEN  = 22,  // sizeof(EthSnapHdrT),
  ETH_MIN_LEN   = 60,
  ETH_MAX_LEN   = 1500,
};


// Access meathods
void      Ethernet_Parse(T_UINT8 *frame, T_UINT16 frameLen);
T_UINT8  *Ethernet_GetHdrP();
void      Ethernet_SetHdrP(T_UINT8 *pHdr);
T_UINT8  *Ethernet_GetdataP();
T_UINT16  Ethernet_GetFrameLength();

// Get values from an Ethernet frame
void     Ethernet_GetSrcMac(T_MacAddr *sa);
void     Ethernet_GetDstMac(T_MacAddr *da);

T_INT16  Ethernet_GetQtagVlanId();

EncapE   Ethernet_GetEncap();
FrmTypE  Ethernet_GetType();
T_UINT16 Ethernet_GetDataLen();                  // return length of L3 data portion

T_UINT16 Ethernet_GetLength();
T_UINT16 Ethernet_GetTypeEthII();

T_UINT8  Ethernet_GetSsap802_2();
T_UINT8  Ethernet_GetDsap802_2();
T_UINT16 Ethernet_GetDsapAndSsap();
T_UINT8  Ethernet_GetCtrl802_2();

T_UINT8  Ethernet_GetCtrlSnap();
T_UINT16 Ethernet_GetTypeSnap();
void     Ethernet_Clear();

// Set values in an Ethernet frame

void Ethernet_SetSrcMac(T_MacAddr *sa);
void Ethernet_SetDstMac(T_MacAddr *da);
void Ethernet_SetEncap(EncapE encap);
void Ethernet_SetType(FrmTypE type);
void Ethernet_SetFrameLen(T_UINT16 frameLen);
void Ethernet_SetDataLen(T_UINT16 dataLength);
void Ethernet_SetLength(T_UINT16 length);
void Ethernet_SetTypeEthII(T_UINT16 type);

void Ethernet_SetDsap802_2(T_UINT8 dsap);
void Ethernet_SetSsap802_2(T_UINT8 ssap);
void Ethernet_SetCtrl802_2(T_UINT8 control);

void Ethernet_SetDsapSnap(T_UINT8 dsap);
void Ethernet_SetSsapSnap(T_UINT8 ssap);
void Ethernet_SetCtrlSnap(T_UINT8 control);
void Ethernet_SetTypeSnap(T_UINT16 type);

T_UINT8 *Ethernet_Create(T_UINT16 dataLen, EncapE encap, FrmTypE type, T_MacAddr *destMac);
void     Ethernet_Init(T_UINT8 *frm);       // Initialize private data
T_UINT16 Ethernet_GsapAndSsap();
void     Ethernet_CreateFrame(T_UINT16 frameLen); 

#endif // __ETHERNET_H__

