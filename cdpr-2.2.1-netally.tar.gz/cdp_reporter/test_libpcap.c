// Filename: test_libpcap.c
// Revision: 2015-01-28 (original)
// Revision: 2018-03-05 (modified to create flag file xdpdump.done)
//
// Description:
//   C program to test the "libpcap" library on a BigRed ARM platform.
//
// To Build for x86 Linux: gcc test_libpcap.c -lpcap
// To Build for ARM with LLDP decode: 
// arm-linux-gnueabi-gcc ethernet.c frmdisp.c ipaddr.c lldp_parse.c cdp_parse.c edp_parse.c macaddr.c test_libpcap.c -L. -lpcap -o lldp_parser.arm
// scp lldp_parser.arm root@192.168.1.149:/tmp
//
// To Run on ARM: scp test_libpcap.arm root@192.168.1.149:/tmp
// To Run on x86 (must be root): sudo ./lldp_parser 10

/*
NOTE: The received packet length can exceed the MTU when GSO is enabled.
      To disable GSO, enter command 'sudo ethtool -K eth0 gso off'
      Also see the settings for "tso" and "gro" below for a Linux PC. 
      For the BigRed TruView Probe, "gso" and "gro" were "on" by default.

$ ethtool -k eth0
Offload parameters for eth0:
rx-checksumming: on
tx-checksumming: on
scatter-gather: on
tcp-segmentation-offload: on
udp-fragmentation-offload: off
generic-segmentation-offload: on  <=== [GSO]
generic-receive-offload: on
large-receive-offload: off
rx-vlan-offload: on
tx-vlan-offload: on
ntuple-filters: off
receive-hashing: off
*/

#include <pcap.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h> // for alarm()
#include <signal.h> // for SIGALRM

#define PROGRAM_VERSION "1.02"
#define DECODE_XDP

#define bool int
#define true 1
#define false 0

#if 1 // decode LLDP
#include "mytypes.h"
#include "frmdisp.h"
char frame_buf[1500];
FILE *outfile = NULL;
#endif

pcap_t *handle = NULL; /* PCAP Session handle */
int filterPktLimit = 0;
int decodedPkt = 0;

// callback function that is passed to pcap_loop()
void my_pktHandler(
  u_char *user_optional_info, 
  const struct pcap_pkthdr* header, 
  const u_char* packet )
{
  static int count = 1;
  static int maxLen = 0;

  decodedPkt = 0;

  int i = 0;
  int k = 0;
  char bcastMac[6] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF };
  //char mySrcMac[6] = { 0x5c, 0x26, 0x0a, 0x1f, 0xb7, 0xbb }; // Linux laptop
  char mySrcMac[6] = { 0x00, 0xc0, 0x17, 0x33, 0x00, 0x38 }; // BigRed

  // special destination MAC addresses...
  // www.juniper.net/documentation/en_US/junos13.2/topics/concept/l2pt-ex-series.html
  char extremeMcast[6] = { 0x00, 0xe0, 0x2b, 0x00, 0x00, 0x00 }; // Extreme Discovery Protocol
  char ciscoMcast[6] = { 0x01, 0x00, 0x0c, 0xcc, 0xcc, 0xcc }; // CDP,VTP,DISL,PAgP,DTP
  char pvstMcast[6] = { 0x01, 0x00, 0x0c, 0xcc, 0xcc, 0xcd }; // Cisco PVST+ (Per-VLAN Spanning Tree)

  char bpduMcast[6] = { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x00 }; // bridge protocol data unit
  char lldpMcast[6] = { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x0e }; // Link-Layer Discovery Protocol (IEEE 802.1ab)
  char stpMcast[6]  = { 0x01, 0x80, 0xc2, 0x00, 0x00, 0x21 }; // spanning tree

  char igmpQuery[6] = { 0x01, 0x00, 0x5e, 0x00, 0x00, 0x01 }; 
  char igmpLeave[6] = { 0x01, 0x00, 0x5e, 0x00, 0x00, 0x02 }; 
  char mdapMcast[6] = { 0x01, 0x00, 0x5e, 0x00, 0x00, 0x67 }; // multi-directory access protocol
  char mDnsMcast[6] = { 0x01, 0x00, 0x5e, 0x00, 0x00, 0xfb }; // multicast DNS
  char llmnrV4[6]   = { 0x01, 0x00, 0x5e, 0x00, 0x00, 0xfc }; // LLMNRv4
  char ssdpMcast[6] = { 0x01, 0x00, 0x5e, 0x7f, 0xff, 0xfa }; // simple service discovery protocol

  char rtrAdvV6[6]  = { 0x33, 0x33, 0x00, 0x00, 0x00, 0x01 }; // IPv6 Router Advertisement
  char rtrSolV6[6]  = { 0x33, 0x33, 0x00, 0x00, 0x00, 0x02 }; // IPv6 Router Solicitation
  char dhcpV6Mcast[6] = { 0x33, 0x33, 0x00, 0x01, 0x00, 0x02 }; // DHCPv6
  char llmnrV6[6]     = { 0x33, 0x33, 0x00, 0x01, 0x00, 0x03 }; // LLMNRv6

  if ( packet == NULL || header->len < 12 ) 
  {
    return;
  }

  if ( header->len > maxLen )
  {
    maxLen = header->len;
  }
 
#if 0 // skip unicast Tx/Rx packets for this host...
  if ( memcmp(packet+6, mySrcMac, 6) == 0 ) // my Tx packet...
  {
    //fprintf(stderr, " (my Tx pkt)\n");
    return;
  }

  if ( memcmp(packet+0, mySrcMac, 6) == 0 ) // my Rx unicast packet...
  {
    //fprintf(stderr, " (my Rx pkt)\n");
    return;
  }
#endif

  fprintf(stderr, "pkt #%d: len=%05u ", count, header->len);
  //fprintf(stderr, "(DEBUG maxLen=%05u) ", maxLen);

  //if ( header->len != 98 ) // linux ping
  if ( 1 )
  {
    fprintf(stderr, "dstMac=");
    for ( i = 0; i < 6; i++ )
    {
      fprintf(stderr, "%02x:", packet[i]);
    }
    if ( memcmp(packet, bcastMac, 6) == 0 )
    {
      fprintf(stderr, " (BCAST)");
    }
    if ( memcmp(packet, ciscoMcast, 6) == 0 )
    {
      fprintf(stderr, " (CDP)");
#ifdef DECODE_XDP
      fprintf(stderr, "\n");
      int frameSize = header->len;
      if ( frameSize > 1500 ) 
      {
        frameSize = 1500;
      }
      memcpy(frame_buf, packet, frameSize);
      FrmDisp_Dispatch_Linked(frame_buf, frameSize);
      fflush(stdout);
      if ( outfile )
        fflush(outfile);
#endif
    }
    if ( memcmp(packet, lldpMcast, 6) == 0 )
    {
      fprintf(stderr, " (LLDP)");
#ifdef DECODE_XDP
      fprintf(stderr, "\n");
      int frameSize = header->len;
      if ( frameSize > 1500 ) 
      {
        frameSize = 1500;
      }
      memcpy(frame_buf, packet, frameSize);
      FrmDisp_Dispatch_Linked(frame_buf, frameSize);
      fflush(stdout);
      if ( outfile )
        fflush(outfile);
#endif
    }
    if ( memcmp(packet, mdapMcast, 6) == 0 )
    {
      fprintf(stderr, " (MDAP)");
    }
    if ( memcmp(packet, mDnsMcast, 6) == 0 )
    {
      fprintf(stderr, " (mDNS)");
    }
    if ( memcmp(packet, ssdpMcast, 6) == 0 )
    {
      fprintf(stderr, " (SSDP)");
    }
    if ( memcmp(packet, igmpQuery, 6) == 0 )
    {
      fprintf(stderr, " (IGMP Query)");
    }
    if ( memcmp(packet, igmpLeave, 6) == 0 )
    {
      fprintf(stderr, " (IGMP Leave)");
    }
    if ( memcmp(packet, rtrAdvV6, 6) == 0 )
    {
      fprintf(stderr, " (IPv6 Router Advert.)");
    }
    if ( memcmp(packet, rtrSolV6, 6) == 0 )
    {
      fprintf(stderr, " (IPv6 Router Solicit.)");
    }
    if ( memcmp(packet, dhcpV6Mcast, 6) == 0 )
    {
      fprintf(stderr, " (DHCPv6)");
    }
    if ( memcmp(packet, llmnrV4, 6) == 0 )
    {
      fprintf(stderr, " (LLMNRv4)");
    }
    if ( memcmp(packet, llmnrV6, 6) == 0 )
    {
      fprintf(stderr, " (LLMNRv6)");
    }
    fprintf(stderr, "\n");
  }

  if (decodedPkt)
  {
      count++; 
  }
  if ( count > filterPktLimit && filterPktLimit > 0 )
  {
    pcap_breakloop(handle);
    return;
  }

#if 0 // DEBUG hexdump...
  fprintf(stderr, "\n");
  for ( i = 0; i < header->len; i++ )
  {
    fprintf(stderr, "%02x ", packet[i]);
    if ( ((i+1) % 16) == 0 )
    {
      fprintf(stderr, "\n");
    }
  }
  fprintf(stderr, "\n");
#endif
}


void alarm_handler(int sig)
{
  pcap_breakloop(handle);
}

static void exiting()
{
    system("rm /var/run/lldp_parser.pid");
    system("touch /tmp/xdpdump.done"); // does this work thru a soft-linked directory ??
    system("sync");
}

int main(int argc, char *argv[])
{
  char *dev; /* The device to sniff on */
  char errbuf[PCAP_ERRBUF_SIZE]; /* Error string */
  struct bpf_program fp; /* The compiled filter */
  char filter_exp[100] = ""; // e.g. tcp port 80"; /* The filter expression */
  bpf_u_int32 mask; /* Our netmask */
  bpf_u_int32 net; /* Our IP */
  int numPkts = 10;
  char szOutfile[100] = "";
  int k = 0;
  int pcapMode = 0;
  bool bFilterEnabled = false;

  // NOTES:
  // - pcap_open_live() with pcap_loop() does NOT honor the timeout
  // - pcap_open_live() with pcap_dispatch() does honor the timeout
  int readTimeoutSeconds = 1; // default to 1 second
  int readTimeoutMsec = 1000 * readTimeoutSeconds; // default to 1 second

  if ( argc > 1 )
  {
    for ( k = 1; k < argc; k++ )
    {
      if ( strncmp(argv[k], "-v", 2) == 0 )
      {
        fprintf(stderr, "%s - version %s\n", argv[0], PROGRAM_VERSION);
        exiting();
        return 1;
      }
      if ( strncmp(argv[k], "-f", 2) == 0 ) // Mode
      {
        bFilterEnabled = true;
        //printf("DEBUG> filterEnabled= %d\n", bFilterEnabled);
      }
      if ( strncmp(argv[k], "-m", 2) == 0 ) // Mode
      {
        pcapMode = atoi(argv[k]+2);
        //printf("DEBUG> pcapMode= %d\n", pcapMode);
      }
      if ( strncmp(argv[k], "-n", 2) == 0 ) // Number of packets
      {
        numPkts = atoi(argv[k]+2);
        filterPktLimit = numPkts;
        //printf("DEBUG> filterPktLimit= %d\n", filterPktLimit);
        numPkts = -1; // don't limit raw packets, but limit filtered packets
      }
      if ( strncmp(argv[k], "-t", 2) == 0 ) // Timeout in msec
      {
        readTimeoutSeconds = atoi(argv[k]+2);
        if ( readTimeoutSeconds <= 0 )
        {
          readTimeoutSeconds = 1; // default to 1 second
        }
        //readTimeoutMsec = readTimeoutSeconds * 1000;
        //printf("DEBUG> timeoutMsec= %d\n", readTimeoutMsec);
      }
      if ( strncmp(argv[k], "-o", 2) == 0 )
      {
        strcpy(szOutfile, argv[k]+2);
        outfile = fopen(szOutfile, "w");
        if ( outfile == NULL )
        {
          fprintf(stderr, "error: could not open output file\n");
          exiting();
          return 1;
        }
      }
    }
  }

  /* Define the device */
  dev = pcap_lookupdev(errbuf);
  if (dev == NULL) 
  {
    fprintf(stderr, "Couldn't find default device: %s\n", errbuf);
    exiting();
    return(2);
  }

  /* Find the properties for the device */
  if (pcap_lookupnet(dev, &net, &mask, errbuf) == -1) 
  {
    fprintf(stderr, "Couldn't get netmask for device %s: %s\n", dev, errbuf);
    net = 0;
    mask = 0;
  }

  /* Open the session in promiscuous mode */
  handle = pcap_open_live(dev, BUFSIZ, 1, readTimeoutMsec, errbuf);
  if (handle == NULL) 
  {
    fprintf(stderr, "Couldn't open device %s: %s\n", dev, errbuf);
    exiting();
    return(2);
  }

  if ( bFilterEnabled )
  {
  /* Filter syntax web references...
  http://www.tcpdump.org/manpages/pcap-filter.7.html
  http://linux.die.net/man/7/pcap-filter
  http://tcpip.marcolavoie.ca/filtering.html "Filtering captured datagrams w/libpcap"
  */
  
  /* Examples of filter expression strings...
    "tcp port 80" // HTTP (web access)
    "tcp port 22" // SCP (secure copy)
    "tcp dst port 22" // SCP (secure copy)
    "tcp src port 22" // SCP (secure copy)
    "udp and less 80" // UDP w/length <= 80 bytes
    "ether proto 0x88d9" // LLTD (like LLDP for Win-XP)
    "ether proto 0x88cc" // LLDP (verified on BigRed w/Netgear switch)
    "ether dst 00:c0:17:33:00:38" // BigRed sample dest MAC
    "host 192.168.1.132" // Host IP address
    "src 192.168.1.132" // source IP address
    "ether broadcast" // includes ARP request/reply
    "ip proto icmp" // includes PINGs
    "icmp[icmptype] = icmp-echo or icmp[icmptype] = icmp-echoreply" // PING (request or reply)
  */

    strcpy(filter_exp, "ether dst 01:00:0c:cc:cc:cc or ether proto 0x88cc"); // CDP or LLDP
  }

  // Compile and apply the filter (could be an empty string for no filter)
  if (pcap_compile(handle, &fp, filter_exp, 0, net) == -1) 
  {
    fprintf(stderr, "Couldn't parse filter %s: %s\n", filter_exp, pcap_geterr(handle));
    exiting();
    return(2);
  }
  if (pcap_setfilter(handle, &fp) == -1) 
  {
    fprintf(stderr, "Couldn't install filter %s: %s\n", filter_exp, pcap_geterr(handle));
    exiting();
    return(2);
  }

  if ( pcapMode == 0 )
  {
#if 1
    alarm(readTimeoutSeconds);
    signal(SIGALRM, alarm_handler);
    printf("DEBUG> installed alarm_handler\n");
#endif
    // pass in our callback function to handle packets
    pcap_loop(handle, numPkts, my_pktHandler, NULL);
  }
  else
  {
    pcap_dispatch(handle, filterPktLimit, my_pktHandler, NULL);
  }

  // And close the session 
  pcap_close(handle);
 
  if ( outfile )
    fclose(outfile);

  exiting();

  return(0);
}
