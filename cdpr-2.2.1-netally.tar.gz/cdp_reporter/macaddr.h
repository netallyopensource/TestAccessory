// ********************************************************
//
// DESCRIPTION  MAC Address Class
// Copyright (c) Fluke Corp, 1996-2007
//
// ********************************************************

#ifndef __MACADDR_H__
#define __MACADDR_H__

#include "mytypes.h"

enum
{
   MAC_ADDR_SIZE = 6,         // digits in a binary MAC address
   MAC_ADDR_STRING_SIZE = 13  // size of string displaying a MAC address + NUL terminator
};


typedef T_UINT8	T_MacAddr[MAC_ADDR_SIZE]; 	// MAC address

// methods

void	 MacAddr_Clear(T_MacAddr *address);

void	 MacAddr_SetAddr(T_MacAddr *address, T_UINT8 *buf);
void     MacAddr_GetAddr(T_MacAddr *address, T_UINT8 *buf);

T_BOOL	 MacAddr_Parse(T_MacAddr *address, T_BYTE *addrStr);
T_UINT16 MacAddr_DataLen();
T_BOOL   MacAddr_IsEqual(const T_MacAddr  *mac1, const T_MacAddr *mac2);
T_BOOL	 MacAddr_IsBcast(const T_MacAddr *address);
T_BOOL	 MacAddr_IsNull(const T_MacAddr *address);
T_BOOL   MacAddr_IsFlukeMacAddr(const T_MacAddr *address);
void     MacAddr_Format(T_MacAddr addr, T_BYTE *str);		// Get formated MAC address

#endif // __MACADDR_H__
