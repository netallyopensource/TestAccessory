#ifndef _MYTYPES_H_
#define _MYTYPES_H_

#include <string.h>
//#define NULL 0
#define far // legacy 16-bit compiler

typedef unsigned char T_BYTE;
typedef unsigned char T_UINT8;
typedef unsigned char UINT8;
typedef unsigned char UCHAR;

typedef unsigned short  T_UINT16;
typedef unsigned short  UINT16;

typedef short  T_INT16;
typedef short  INT16;

typedef unsigned long T_UINT32;
typedef unsigned long UINT32;

typedef long T_INT32;
typedef long INT32;

typedef float T_FLOAT;

typedef enum {FALSE, TRUE} T_BOOL;
//#define FALSE 0
//#define TRUE  1

typedef T_BYTE     *T_pBYTE;   /* pointer to a byte */
typedef T_BYTE far *T_fpBYTE;  /* far pointer to a byte */

typedef struct { T_UINT8 x;
                 T_UINT8 y; } T_Point;

typedef T_BYTE T_BITMAP;

// The far pointer to a Bitmap must be used to access the bitmaps in ROM.
typedef T_BYTE far * T_pBitmap; 

typedef T_BYTE T_HEIGHT;
typedef T_BYTE T_WIDTH;

typedef enum { LANG_ENGLISH, 
               LANG_JAPANESE } T_Language; 
                
typedef enum { UNITS_FEET = 0,
               UNITS_METERS = 1 } T_LengthUnits;               
                               
typedef enum { AUTOOFF_NONE = 0,
               AUTOOFF_10MINUTES = 1 } T_AutoOff;
                               
typedef enum { FINAL_TEST_FAILED = 0,
               FINAL_TEST_PASSED = 1 } T_FinalTest;

///////////////////////////////////////////////////////////////////////////////
// If 802.1X authentication breaks when changing non-802.1X related code,
// toggle the define below (from #define to #undef, or from #undef to #define).
// By toggling, we shift all global variables stored after g_SystemConfig to
// either an even or odd byte boundary.
#define MULTI_LANGUAGE_SUPPORT
//#undef  MULTI_LANGUAGE_SUPPORT

#ifdef MULTI_LANGUAGE_SUPPORT
typedef struct { T_BYTE lengthUnits   : 1;
                 T_BYTE tonePattern : 1;
                 T_Language language; } T_SystemConfig;
#endif
///////////////////////////////////////////////////////////////////////////////

typedef void (* T_pFunc)();
typedef T_BOOL (* T_pbFunc)();

typedef enum 
{
	RANGE_LENGTH = 0,
	RANGE_VOLTS = 1,
	RANGE_NUM_RANGES = 2
} T_Range;
                
typedef enum { MUX_ENABLE = 0, MUX_DISABLE = 1 } T_MuxControl;

typedef enum { MEAS_RESISTANCE = 0,  MEAS_LENGTH = 1 } T_MeasType; 

typedef enum { TXRX_NORMAL = 0, TXRX_SWAPPED = 1 } T_SwapState ;

// these pin definitions align with the selections made through the mux
// when measuring pins and pairs.
typedef enum
{
	PIN_ONE    = 0,
	PIN_TWO    = 1,
	PIN_THREE  = 2,
	PIN_FOUR   = 3,
	PIN_FIVE   = 4,
	PIN_SIX    = 5,
	PIN_SEVEN  = 6,
	PIN_EIGHT  = 7,
	PIN_NUM_PINS = 8,
	PIN_NO_PIN   = 0xFF
} T_Pin;
                
 
typedef enum { LOW_RES, HIGH_RES } T_GraphRes;

// 16-Oct-2001 T. Doumas
// Use this to access the results, current and next. See Results.h and ConfigResults.h
// This was in Results.h but I moved it here to make it more accessible for the config
// stuff.
typedef enum { CURRENT_RESULT    = 0,
               NEXT_RESULT       = 1,
               ORIGINAL_RESULT   = 2,
               NUM_RESULTS } T_WhichResult;

// Macro to do byte swapping on an unsigned int
#define BS(val) (T_UINT16) (((T_UINT16) (val) >> 8) | ((T_UINT16) (val) << 8))
// Macros to provide the MS Word and LS word of a long
// These macros are NOT portable they MUST be swapped when the code is
// moved from a big to a little endian architecture or visa versa.
// e.g. LSW is MSW for a little endian CPU and MSW becomes LSW 
#define MSW(lval) (*((T_UINT16 *) (((T_UINT16 *)&(lval))+1)))
#define LSW(lval) (*((T_UINT16 *) &(lval)))

// Macro to do byte swapping on an unsigned long
#define LS(lval) (T_UINT32) (BS(MSW(lval)) | ((T_UINT32) BS(LSW(lval))) << 16)
                                     
#endif /* _MYTYPES_H_ */
