// ********************************************************
//
// DESCRIPTION  Parse or create Ethernet frames
// Copyright (c) Fluke Corp, 1996-2007
//
// ********************************************************
#include <stdio.h>
#include <string.h>

#include "mytypes.h" 

#include "macaddr.h"
#include "ipaddr.h"
#include "frmtype.h"
#include "ethernet.h"


static T_UINT8 *Ethernet_hdrP;     // the Ethernet frame
static T_UINT8 *Ethernet_dataP;    // data portion of Ethernet frame
static T_UINT16 Ethernet_frameLen; // Length of frame excluding FCS
static T_INT16  Ethernet_qtagVlanId; // 802.1Q VLAN ID
static EncapE   Ethernet_encap;    // Encapsulation
static FrmTypE  Ethernet_type;     // Ethernet frame type
//
// Initialize the private data
//
void Ethernet_init(T_UINT8 *frm)
{
  Ethernet_hdrP  = frm;
  Ethernet_dataP = NULL;
  Ethernet_encap = ENCAP_NONE;
  Ethernet_type  = FRMTYPE_NONE;
  Ethernet_frameLen = 0;
  Ethernet_qtagVlanId = -1;
}

//
// Parse an Ethernet frame
//
void Ethernet_Parse(T_UINT8 *frame, T_UINT16 frameLen)
{
  //int tmpInt = 0; // DEBUG only
  T_UINT16 rawVlanId = 0;
  Ethernet_hdrP = frame;
  Ethernet_frameLen = frameLen;
  Ethernet_qtagVlanId = -1;

  //fprintf( stderr, "DEBUG> in Ethernet_Parse()\n" );
  //fprintf( stderr, "DEBUG> frameLen= %d\n", frameLen );
  //hexdump( frame, frameLen );

  //tmpInt = Ethernet_GetLength();
  //tmpInt = tmpInt & 0xFFFF;
  //fprintf( stderr, "DEBUG> Ethernet_GetLength()= %04x\n", tmpInt );
  
  if ( Ethernet_GetLength() == VLAN_TYPE ) // compare word after byte swapping
  {
  	// 802.1Q Virtual LAN frame

    // save VLAN ID for GUI and Reports
  	rawVlanId = *((T_INT16*)(Ethernet_hdrP+ETH_RAW_LEN));
  	Ethernet_qtagVlanId = BS(rawVlanId) & 0x0FFF;

    // skip over QTAG field
  	Ethernet_hdrP += QTAG_SIZE;
  	Ethernet_frameLen -= QTAG_SIZE;
  } 

  if (Ethernet_GetLength() > ETH_MAX_LEN)
  {
    Ethernet_encap = ETH_II;
    Ethernet_dataP = Ethernet_hdrP + ETH_II_LEN;
    Ethernet_type  = (FrmTypE) Ethernet_GetTypeEthII();
  }
  else
  {
    switch (Ethernet_GetDsapAndSsap())
    {
      case NOV_RAW_SAPS:
        Ethernet_encap = ETH_NOV_RAW;
        Ethernet_dataP = Ethernet_hdrP + ETH_RAW_LEN;
        Ethernet_type  = (FrmTypE) NOV_RAW_SAPS;
        break;

      case SNAP_SAPS:
        Ethernet_encap = ETH_SNAP;
        Ethernet_dataP = Ethernet_hdrP + ETH_SNAP_LEN;
        Ethernet_type  = (FrmTypE) Ethernet_GetTypeSnap();
        break;

      default:
        Ethernet_encap = ETH_802_2;
        Ethernet_dataP = Ethernet_hdrP + ETH_802_2_LEN;
        Ethernet_type  = (FrmTypE) Ethernet_GetDsap802_2();
        break;
    }
  }
}

//
// Return the data length of an Ethernet frame
//
T_UINT16 Ethernet_DataLen()
{
  T_UINT16 dataLength;

  switch (Ethernet_encap)
  {
    case ETH_NOV_RAW:
      dataLength = Ethernet_GetLength();
      break;

    case ETH_802_2:
      dataLength = Ethernet_GetLength() - (ETH_802_2_LEN - ETH_RAW_LEN);
      break;

    case ETH_SNAP:
      dataLength = Ethernet_GetLength() - (ETH_SNAP_LEN - ETH_RAW_LEN);
      break;

    case ETH_II:
    default:
      // data length not part of packet
      dataLength = Ethernet_frameLen - ETH_II_LEN;
      break;
  }

  if (dataLength > Ethernet_frameLen)
  {
    dataLength = 0;  // this should not happen
  }

  return dataLength;
}



// Get and set the Ethernet frame pointer
T_UINT8 *Ethernet_GetHdrP()           { return Ethernet_hdrP; }

void Ethernet_SetHdrP(T_UINT8 *pHdr)  { Ethernet_hdrP = pHdr; }

// Get the pointer to the ethernet frame's data portion
T_UINT8 *Ethernet_GetdataP()          { return Ethernet_dataP; }
// Get the whole frame length w/o fcs
T_UINT16 Ethernet_GetFrameLength()   { return Ethernet_frameLen; }

T_INT16 Ethernet_GetQtagVlanId()   { return Ethernet_qtagVlanId; }

// Get values from an Ethernet frame
void Ethernet_GetSrcMac(T_MacAddr *sa)
{ 
     T_UINT8* pSrcMac = (T_UINT8*)((T_EthIIHdr *)Ethernet_hdrP)->srcAddr;
     MacAddr_SetAddr(sa, pSrcMac);
}

void Ethernet_GetDstMac(T_MacAddr *da)
{ 
     T_UINT8* pDestMac = (T_UINT8*)((T_EthIIHdr *)Ethernet_hdrP)->dstAddr;
     MacAddr_SetAddr(da, pDestMac);
}

EncapE   Ethernet_GetEncap()          { return Ethernet_encap; }
FrmTypE  Ethernet_GetType()           { return Ethernet_type; }

T_UINT16 Ethernet_GetLength()         { return BS(((T_Eth802_3Hdr *)Ethernet_hdrP)->length); }


T_UINT16 Ethernet_GetTypeEthII()      { return BS(((T_EthIIHdr *)Ethernet_hdrP)->type); }
T_UINT8  Ethernet_GetDsap802_2()       { return ((T_Eth802_2Hdr *)Ethernet_hdrP)->dsap; }
T_UINT8  Ethernet_GetSsap802_2()      { return ((T_Eth802_2Hdr *)Ethernet_hdrP)->ssap; }
T_UINT8  Ethernet_GetCtrl802_2()      { return ((T_Eth802_2Hdr *)Ethernet_hdrP)->control; }
T_UINT8  Ethernet_GetCtrlSnap()       { return ((T_EthSnapHdr *)Ethernet_hdrP)->control; }
T_UINT16 Ethernet_GetTypeSnap()       { return BS(((T_EthSnapHdr *)Ethernet_hdrP)->type); }
T_UINT16 Ethernet_GetDsapAndSsap()    { return ((T_UINT16)((T_UINT16)Ethernet_GetDsap802_2() << 8) | (T_UINT16)Ethernet_GetSsap802_2()); }
void Ethernet_Clear()                 { Ethernet_hdrP = NULL; }

// Set values in an Ethernet frame
void Ethernet_SetSrcMac(T_MacAddr *sa)         
{ 
     MacAddr_GetAddr(sa, (T_pBYTE)((T_EthIIHdr *)Ethernet_hdrP)->srcAddr); 
}

void Ethernet_SetDstMac(T_MacAddr *da)         
{ 
     MacAddr_GetAddr(da, (T_pBYTE)((T_EthIIHdr *)Ethernet_hdrP)->dstAddr); 
}

void Ethernet_SetEncap(EncapE encap)          { Ethernet_encap = encap; }
void Ethernet_SetType(FrmTypE type)           { Ethernet_type = type; }
void Ethernet_SetFrameLen(T_UINT16 frameLen)  { Ethernet_frameLen = frameLen; }
void Ethernet_SetDataLen(T_UINT16 dataLength) {}
void Ethernet_SetLength(T_UINT16 length)      { ((T_Eth802_3Hdr *)Ethernet_hdrP)->length = BS(length); }
void Ethernet_SetTypeEthII(T_UINT16 type)     { ((T_EthIIHdr *)Ethernet_hdrP)->type = BS(type); }
void Ethernet_SetDsap802_2(T_UINT8 dsap)      { ((T_Eth802_2Hdr *)Ethernet_hdrP)->dsap = dsap; }
void Ethernet_SetSsap802_2(T_UINT8 ssap)      { ((T_Eth802_2Hdr *)Ethernet_hdrP)->ssap = ssap; }
void Ethernet_SetCtrl802_2(T_UINT8 control)   { ((T_Eth802_2Hdr *)Ethernet_hdrP)->control = control; }
void Ethernet_SetDsapSnap(T_UINT8 dsap)       { ((T_EthSnapHdr *)Ethernet_hdrP)->dsap = dsap; }
void Ethernet_SetSsapSnap(T_UINT8 ssap)       { ((T_EthSnapHdr *)Ethernet_hdrP)->ssap = ssap; }
void Ethernet_SetCtrlSnap(T_UINT8 control)    { ((T_EthSnapHdr *)Ethernet_hdrP)->control = control; }
void Ethernet_SetTypeSnap(T_UINT16 type)      { ((T_EthSnapHdr *)Ethernet_hdrP)->type = BS(type); }    

