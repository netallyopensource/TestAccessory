// ********************************************************
//
// DESCRIPTION  Parse LLDP frames (Link Layer Discovery Protocol)
// Copyright (c) Fluke Corp, 2006-2007
//
// ********************************************************

#ifndef __LLDP_PARSE_H__
#define __LLDP_PARSE_H__

#include "mytypes.h"


// ****************************************************
// Tag values for TLV fields
// ****************************************************
typedef enum 
{
    TLV_OFFSET       = 0,   // first TLV field starts 0 bytes into LLDP data

    TAG_CHASSIS_ID  = 0x01, // mandatory chassis ID (usually with switch MAC address)
    TAG_PORT_ID     = 0x02, // mandatory port ID
    TAG_PORT_DESCR  = 0x04, // optional port description
    TAG_SYSTEM_NAME = 0x05, // optional system name string
    TAG_CAPABILITIES= 0x07, // optional capabilities
    TAG_MGMT_ADDRESS= 0x08, // optional management IP address
    TAG_END_OF_LLDP = 0x00, // optional management IP address
    TAG_ORG_SPECIFIC= 0x7F, // optional organization specific (for VLAN ID)
} TlvTagE;

typedef enum
{
    LLDP_CAP_OTHER     = 0x0001,
    LLDP_CAP_REPEATER  = 0x0002,
    LLDP_CAP_BRIDGE    = 0x0004,
    LLDP_CAP_WAP       = 0x0008,
    LLDP_CAP_ROUTER    = 0x0010,
    LLDP_CAP_TELEPHONE = 0x0020,
    LLDP_CAP_DOCSIS    = 0x0040,
    LLDP_CAP_STATION   = 0x0080,
    LLDP_CAP_RESERVED  = 0xFF00
} TlvCapabilitiesE;

// ****************************************************
// TLV header
// ****************************************************
typedef struct
{
    T_UINT8  tag;        // the TLV tag
    T_UINT8  length;     // total length of this TLV (header & data)
} T_LLDPHeader;


// LLDP Protocol access methods

void     LLDP_SetHdrP(T_UINT8 *hdrp);
T_UINT8 *LLDP_GetHdrP(void);

T_BOOL LLDP_GetSrcIp(T_UINT8 *ip, T_UINT8 size);
T_BOOL LLDP_GetEnabledCapabilities(T_UINT16 *cap);
T_BOOL LLDP_GetName(char *name, int size);
T_BOOL LLDP_GetPort(char *port, int size);
T_BOOL LLDP_GetSwitchMac(T_UINT8 *mac);
T_BOOL LLDP_GetVlanId(T_BYTE **value);
T_BOOL LLDP_GetVoiceTLV(T_BYTE **value);

// Reset current TLV pointer to beginning of frame
void LLDP_ResetCurrTlvPointer();

// Position the current TLV to the specified field
T_BOOL LLDP_FindTlv(TlvTagE tag, T_BOOL bContinued);

// Get the tag, length, and data for the current TLV field
T_UINT16  LLDP_GetTag(void);
T_UINT16  LLDP_GetLength(void); 
T_UINT8  *LLDP_GetDataPtr(void);
T_UINT16  LLDP_GetDataLen(void);
T_BOOL    LLDP_GetData(char *str, int size);

#endif // __LLDP_H_
