// ********************************************************
//
// DESCRIPTION  Frame type and encapsulation defines
// Copyright (c) Fluke Corp, 1996-2007
//
// ********************************************************

#ifndef __FRMTYPE_H__
#define __FRMTYPE_H__

//
// Encapsulation types
//
typedef enum  
{
  ENCAP_NONE		= 0,
  ETH_802_2			= 0x01,
  ETH_NOV_RAW		= 0x02,			// ie. 802.3 (raw)
  ETH_II			= 0x04,
  ETH_SNAP			= 0x08,
  //ETH_802_1Q        = 0x10,
} EncapE;

//
// Frame types <=255 is DSAP, > 0x5FF is EtherType
//
typedef enum
{
  FRMTYPE_NONE		= 0,
  BPDU_SAP			= 0x42,
  MS_DLC_1      	= 0xC4,      	// Microsoft Data Link Control
  MS_DLC_2      	= 0xD4,
  MS_DLC_3      	= 0xB4,
  MS_DLC_4      	= 0xB5,
  SNAP_SAP			= 0xAA,
  SNAP_SAPS			= 0xAAAA,		// DSAP & SSAP
  IPX_SAP			= 0xE0,
  BEUI_SAP			= 0xF0,
  BEUI_1_SAP		= 0xF1,
  NOV_RAW_SAP		= 0xFF,
  NOV_RAW_SAPS		= 0xFFFF,		// the IPX checksum for 802.3 raw
  EXTREME_EDP_TYPE  = 0x00BB,
  BAY_MNG1_TYPE		= 0x01A1,
  BAY_MNG2_TYPE		= 0x01A2,
  BAY_MNG3_TYPE		= 0x01A3,
  LAT_SPAN_TYPE		= 0x01A4,
  CISCO_CDP_TYPE	= 0x2000,
  IP_TYPE			= 0x0800,
  ARP_TYPE			= 0x0806,
  RARP_TYPE			= 0x8035,
  DEC_BRG_TYPE		= 0x8038,
  APPLETALK_TYPE	= 0x809B,		// Appletalk
  APPLETALK_ARP_TYPE= 0x80F3,		// Appletalk Arp
  VLAN_TYPE			= 0x8100,		// VLAN type
  IPX_TYPE			= 0x8137,		// IPX
  EPOL_TYPE			= 0x888E,		// EPOL type
  LLDP_TYPE			= 0x88CC,		// LLDP
  IPV6_TYPE			= 0x08dd,
}  FrmTypE;

#define EAPOL_TYPE_START 1

//
// Address class bit masks
//
enum AddrFlagsE 
{
   ADR_SELF			= 0x01,
   ADR_BCAST		= 0x02,
   ADR_MCAST		= 0x04,
   ADR_PROM			= 0x08,
   ADR_ANY			= 0xFF,
};

#endif // __FRMTYPE_H__
