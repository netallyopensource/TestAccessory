#ifndef _DISCOVERY_H_
#define _DISCOVERY_H_


// enums for Discovery Protocol (DP) issues

// Note: All *_LENGTH defines below are odd for even word alignment in struct
#define	MAX_DP_ID_LENGTH     271 // Cisco 6509 showed max deviceId of 268 chars

typedef enum
{
    DP_NO_DATA         = 0x00,
    DP_DEVICE_ID_VALID = 0x01,
    DP_ADDRESS_VALID   = 0x02,
    DP_PORT_VALID      = 0x04,
    DP_VLAN_VALID      = 0x08,
    DP_CDP_TYPE        = 0x10,
    DP_EDP_TYPE        = 0x20,
    DP_LLDP_TYPE       = 0x40,
    DP_TYPE_MASK       = 0xF0,
} T_DPData;


// used to store data from CDP/EDP/LLDP packets
/*
typedef struct
{
	char     deviceId [MAX_DP_ID_LENGTH+1];  // name of device
	char     address [ MAX_DP_ID_LENGTH+1];         // IP or MAC address
	char     portId [  MAX_DP_ID_LENGTH+1];      // slot and port
	char     vlanId [  MAX_DP_ID_LENGTH+1];      // native VLAN ID
	T_DPData validData;
} T_DiscoveryProtocolData;
*/

#endif // _DISCOVERY_H_
