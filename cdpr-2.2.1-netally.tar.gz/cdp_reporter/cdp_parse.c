// ********************************************************
//
// DESCRIPTION  Parse CDP frames
//
// Copyright (c) Fluke Corp, 2004
//
//
// ********************************************************

#include <string.h>
#include <stdlib.h>
#include "mytypes.h"
#include "cdp_parse.h"

#define MAX_FRAME_LENGTH 2048

static T_CDPHeader *CDP_hdrP;        // points to start of CDP header


//
// Search for the specified type
//   
int CDP_GetType(T_UINT16 type, char **value)
{
	int i;
	T_UINT16 dummy;
	T_UINT16 length;
	T_UINT8 *cptr;

	// setup for search
	*value = NULL;

	// Get the type.
	// Return when either the maximum bytes are processed or the type is found.
	cptr = (T_UINT8*)&(CDP_hdrP->type);
	for (i = 0; i < MAX_FRAME_LENGTH; )
	{
		// get the type
	//	dummy = (*cptr << 8) | *(cptr+1);
		dummy = *cptr;
		dummy <<= 8;
		dummy |= *(cptr+1);

		if (dummy == type)
		{
			// match found, get length and value pointer
//			length = (*(cptr+2) << 8) | *(cptr+3);
			length = *(cptr+2);
			length <<= 8;
			length |= *(cptr+3);
			if ( length > 4 )
                        {
				length -= 4;
			}
			else
			{
				length = 0;
			}
			*value = cptr + 4;
			//return TRUE;
			return length;
		}
		else
		{
			// skip the current type section and keep looking
			// get the length
//			dummy = (*(cptr+2) << 8) | *(cptr+3);
			dummy = *(cptr+2);
			dummy <<= 8;
			dummy |= *(cptr+3);

			// see if we are lost
			if (dummy == 0)
				return FALSE;

			cptr += dummy;
			// increment the safety counter
			i += dummy;
		}
	}
	//return FALSE;
	return 0;
}
// return the first NLPID IP address in this field
T_BOOL CDP_GetAddress(T_BYTE *ptr, T_UINT16 packet_length, char **value)
{
	// ptr points to the address section of the packet
	//   Uint8    protocol
	//   uint8    length of protocol descriptor field
	//   variable protocol decscriptor
	//   uint16   address length
	//   variable address
	// 
	//   extract an IP address from the packet
	//     protocol       = NLPID
	//     length         = 1
	//     protocol des   = x0cc
	//     address length = 4 bytes
	//     address        = ip address
	//

	int i;
	T_UINT16 dummy;
	T_UINT8 *lptr = ptr;  // local pointer

	// setup for search
	*value = NULL;

	// Return when either the maximum bytes are processed or the address is found.
	for (i = 0; (i < MAX_FRAME_LENGTH) && (i < packet_length); )
	{
		// get the type
		if (*ptr == CPD_ADDRESS_PROTOCOL_NLPID)              // protocol
		{
			if (*(ptr+1) == 1)                               // length
			{
				if (*(ptr+2) == CPD_ADDRESS_PROTOCOL_TYPE)   // protocol type
				{
					// get address length
//					dummy = (*(ptr+3) << 8) | *(ptr+4);
					dummy = *(ptr+3);
					dummy <<= 8;
					dummy |= *(ptr+4);

					if (dummy == 4)                          // protcol length
					{
						*value = ptr+5;
						return TRUE;
					}
				}
			}
		}
		else
		{
			// go to next address
			// skip protocol part
			ptr += (1 + *(ptr+1)) + 1;  // protocol length + protocol + location for address length
//			ptr += (((*ptr << 8) | *(ptr+1)) + 1);  // address length + location of next byte
			dummy = *ptr;
			dummy <<= 8;
			dummy |= *(ptr+1);
			dummy += 1;
			ptr += dummy;


			// increment the safety counter
			i += (ptr - lptr);
		}
	}
	return FALSE;
}


// Access methods
void        CDP_SetHdrP(T_UINT8 *hdrp)    { CDP_hdrP = (T_CDPHeader *) hdrp; }
T_UINT8    *CDP_GetHdrP()                 { return ((T_pBYTE) CDP_hdrP); }

//
// Get Elements of the CDP message
//
T_UINT8   Bootp_GetVersion(void)          { return CDP_hdrP->version; }
T_UINT8   Bootp_GetTTL(void)              { return CDP_hdrP->ttl; }
T_UINT16  Bootp_GetChecksum(void)         { return CDP_hdrP->checksum; }








