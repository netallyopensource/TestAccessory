// ********************************************************
//
// DESCRIPTION  MAC Address Class
// Copyright (c) Fluke Corp, 1996-2007
//
// ********************************************************
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mytypes.h"
#include "macaddr.h"


// some useful globally accessable MAC addresses
const T_MacAddr macZero  = { 0, 0, 0, 0, 0, 0 };
const T_MacAddr macBcast = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
//
// Clear MAC Address
//
void MacAddr_Clear(T_MacAddr *address)
{
	memset(address, 0, MAC_ADDR_SIZE);
}

//
// Set a MAC address from a memory location
//
void MacAddr_SetAddr(T_MacAddr *address, T_UINT8 *buf)
{
    T_UINT8 i;
    T_BYTE *addr = (T_BYTE *)address; // temporary variable to keep from repeating the 
                                      // cast operation on address      
    for (i = 0; i < MAC_ADDR_SIZE; ++i)
    {
        *addr++ = *buf++;
    }       
//    memcpy(address, buf, MAC_ADDR_SIZE);
}

//
// Put a MAC address into a memory location
//
void MacAddr_GetAddr(T_MacAddr *address, T_UINT8 far *buf)	
{
    T_UINT8 i;
    T_BYTE *addr = (T_BYTE *)address; // temporary variable to keep from repeating the 
                                      // cast operation on address      
    for (i = 0; i < MAC_ADDR_SIZE; ++i)
    {
        *buf++ = *addr++;
    }       
//    memcpy(buf, address, MAC_ADDR_SIZE);
}

//
// Set the MAC address given a string
// The original plan was to use sscanf(), but the 
// library in the NC30 compiler doesn't seem to work 
// properly.  It refuses to convert leading zeros.
// The BRUTE FORCE technique used here introduces some
// non-portable attributes such as the LS (long swap) macro
// and the need to know data type sizes in bytes.  
// *** SO BEWARE ***
//
// I now back to using sscanf() however the leading zeros must be preceeded by
// 2 bogus leading zeros for the conversion to work correctly.  This may mess up
// mac addresses that don't have leading zeros, but all Fluke macs have them.
//

T_BOOL MacAddr_Parse(T_MacAddr *address, T_BYTE *addrStr)
{
	T_UINT16 num;
    T_UINT8 i = 0;
    T_UINT8 j = 0;
    T_UINT8 tmpStr[17];
	T_UINT8 *add = (T_pBYTE)address;
    memset (tmpStr, ' ', sizeof(tmpStr));
    do 
    {
        tmpStr[i++] = addrStr[j++];    
        tmpStr[i++] = addrStr[j++];    
        ++i;
    } while (j < (MAC_ADDR_STRING_SIZE - 1));      
    
	num = sscanf((const char*)tmpStr, "%2x%2x%2x%2x%2x%2x", add, add+1, add+2, add+3, add+4, add+5);
	return (T_BOOL) (num == MAC_ADDR_SIZE);
}


//
//  Returns the length of a binary MAC address
//
T_UINT16 MacAddr_DataLen()
{
    return MAC_ADDR_SIZE;
}

//
// Replaces == operator from C++
//
T_BOOL  MacAddr_IsEqual(const T_MacAddr *mac1, const T_MacAddr *mac2)
{
    return (T_BOOL) !(memcmp(mac1, mac2, MAC_ADDR_SIZE));
}
    


T_BOOL	MacAddr_IsBcast(const T_MacAddr *address)
{
    return MacAddr_IsEqual(address, &macBcast);
}

T_BOOL	MacAddr_IsNull(const T_MacAddr *address)
{
    return MacAddr_IsEqual(address, &macZero);
}


//
// Is this a Fluke Device?
//
T_BOOL MacAddr_IsFlukeMacAddr(const T_MacAddr *address)
{
    T_UINT8 far *addr = (T_UINT8 far *)address;
	if (addr[0]==0x00 && 
		addr[1]==0xc0 && 
		addr[2]==0x17)
	{
		return TRUE;
	}
	return FALSE;
}


//
// Get formatted MAC address into a string buffer for display
// string buffer will be NUL terminated
void MacAddr_Format(T_MacAddr addr, T_BYTE *str)
{
	sprintf((char*)str, "%02x%02x%02x%02x%02x%02x", addr, addr + 1, addr + 2, addr + 3, addr + 4, addr + 5);
}

