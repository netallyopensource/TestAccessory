#ifndef _FRAME_DISPATCHER_H_
#define _FRAME_DISPATCHER_H_

#include "mytypes.h"


#define ORIGINAL_CDP_PARSER
#undef  ORIGINAL_CDP_PARSER

T_UINT16 FrmDisp_Dispatch_Linked(char *frameBuf, T_UINT16 frameSize);

void FrmDisp_ParseLLDP();
void FrmDisp_ParseCDP(int qtagVlanId);
void FrmDisp_ParseEDP();
void configLldpVoiceVlan(unsigned int id, unsigned int l2_pri, unsigned int l3_pri);
void configCdpVoiceVlan(unsigned int id);

//void FrmDisp_ParseEPOL();

#endif // _FRAME_DISPATCHER_H_
