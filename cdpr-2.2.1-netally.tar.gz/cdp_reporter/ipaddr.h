// ********************************************************
//
// DESCRIPTION  IP Address Class
// Copyright (c) Fluke Corp, 1996-2007
//
// ********************************************************

#ifndef __IPADDR_H__
#define __IPADDR_H__


#include "mytypes.h"

enum
{ 
    IP_ADDR_SIZE = 4,      // size of raw IP address
    IPV4_STRING_SIZE = 16  // size of string displaying a IP address + NUL terminator
};
typedef enum
{
    CLASS_A,
    CLASS_B,
    CLASS_C,
    CLASS_D,
    CLASS_E,
} T_IpClass;

typedef unsigned long T_IpAddr ;    // IP address

void      IpAddr_Clear(T_IpAddr *address);
void      IpAddr_SetAddr(T_IpAddr *address, T_BYTE *buf);
void      IpAddr_GetAddr(T_IpAddr *address, T_BYTE *buf);
T_UINT16  IpAddr_DataLen();
T_BOOL    IpAddr_Parse(T_IpAddr *address, T_BYTE *addrStr);
void      IpAddr_Format(T_IpAddr *const address, T_BYTE *str); // Get formatted IP address
T_BOOL    IpAddr_IsSelf(T_IpAddr address);
T_BOOL    IpAddr_IsBcast(T_IpAddr address);
T_BOOL    IpAddr_IsLoopback(T_IpAddr address);
T_BOOL    IpAddr_IsNull(T_IpAddr address);
T_IpClass IpAddr_IpClass(T_IpAddr address);
T_UINT32  IpAddr_MinValidMask(T_IpAddr address);

#endif // __T_IpAddr_H__

