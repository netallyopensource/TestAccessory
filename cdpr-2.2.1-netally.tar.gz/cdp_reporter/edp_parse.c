// ********************************************************
//
// DESCRIPTION  Parse EDP frames
//
// Copyright (c) Fluke Corp, 2004
//
//
// ********************************************************

#include <string.h>
#include <stdlib.h>
//#include "timerdefs.h"
#include "mytypes.h"
#include "edp_parse.h"
//#include "Xilinx.h"
#include "discovery.h"

#define MAX_FRAME_LENGTH 2048

static T_EDPHeader *EDP_hdrP;        // points to start of EDP header


//
// Search for the specified type
//   
T_BOOL EDP_GetType(T_UINT16 type, T_BYTE **value, int *pOffset)
{
	int i;
	T_UINT16 dummy;
	T_UINT8 *cptr;
	T_BOOL bMatchFound = FALSE;
	int offset = 0;

	// setup for search
	*value = NULL;

	// Get the type.
	// Return when either the maximum bytes are processed or the type is found.
	cptr = (T_UINT8*)EDP_hdrP;

	// skip the header
	cptr += sizeof(T_EDPHeader);

	if ( pOffset != NULL && *pOffset > 0 )
	{
		offset = *pOffset;
		cptr += offset;
	}

	// search for type
	for (i = offset; i < MAX_FRAME_LENGTH; )
	{
		// get the type
		dummy = *cptr;
		dummy <<= 8;
		dummy |= *(cptr+1);

		if (dummy == EDP_END_TYPE)
		{
			return FALSE;
		}
		else if (dummy == type)
		{
			// match found
			*value = cptr;
			bMatchFound = TRUE;
		}
		
		// skip the current type section and keep looking
		// get the length
		dummy = *(cptr+2);
		dummy <<= 8;
		dummy |= *(cptr+3);

		// see if we are lost
		if (dummy == 0)
			return FALSE;

		cptr += dummy;
		// increment the safety counter
		i += dummy;
		
		if ( bMatchFound )
		{
			if ( pOffset != NULL )
			{
				*pOffset = i;
			}
			return TRUE;
		}
	}
	return FALSE;
}


// return a pointer to the MAC address
T_BOOL EDP_GetAddress(char **value)
{
	*value = (T_BYTE*)&EDP_hdrP->device_address;
	return TRUE;
}


T_BOOL   EDP_GetSlot(char **value)
{
	T_BYTE *ptr;

	if (EDP_GetType(EDP_GENERAL_TYPE, &ptr, NULL))
	{
		*value = (T_BYTE*)&(((T_EDPGeneral*)ptr)->slot);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}


T_BOOL   EDP_GetPort(char **value)
{
	T_BYTE *ptr;

	if (EDP_GetType(EDP_GENERAL_TYPE, &ptr, NULL))
	{
		*value = (T_BYTE*)&(((T_EDPGeneral*)ptr)->port);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}


T_BOOL   EDP_GetVlan(char far *szVlanId)
{
	T_BYTE *ptr;
	T_BOOL bFoundVlanId = FALSE;
	int nVlanId = -1;
	int nOffset = 0;
	char szTemp[MAX_DP_ID_LENGTH+1] = "";

	// grab first VlanID if it exists
	while ( EDP_GetType(EDP_VLAN_ID_TYPE, &ptr, &nOffset) )
	{
		nVlanId = ((T_EDPVlanInfo*)ptr)->nVlanId;
		nVlanId = BS(nVlanId);
		if ( !bFoundVlanId )
		{
			bFoundVlanId = TRUE;
			sprintf( (char far*)szVlanId, "VLAN%04d", nVlanId );
		}
		else
		{
			// append additional VlanIDs
			sprintf( (char far*)szTemp, ", %04d", nVlanId );
			strcat( (char far*)szVlanId, (char far*)szTemp );
			if ( strlen((char far*)szVlanId) > (MAX_DP_ID_LENGTH - 7) )
			{
				break;
			}
		}
	}
	
	if ( bFoundVlanId )
	{
		return TRUE;
	}
	
	return FALSE;
}


T_BOOL   EDP_GetName(char **value)
{
	T_BYTE *ptr;

	if (EDP_GetType(EDP_NAME_TYPE, &ptr, NULL))
	{
		*value = (T_BYTE*)&(((T_EDPName*)ptr)->str);
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}


T_BOOL   EDP_GetNameLength(T_UINT16 *value)
{
	T_BYTE *ptr;

	if (EDP_GetType(EDP_NAME_TYPE, &ptr, NULL))
	{
		*value = ((T_EDPName*)ptr)->record_length;
		return TRUE;
	}
	else
	{
		return FALSE;
	}
}

// Access methods
void        EDP_SetHdrP(T_UINT8 *hdrp)    { EDP_hdrP = (T_EDPHeader *) hdrp; }
T_UINT8    *EDP_GetHdrP()                 { return ((T_pBYTE) EDP_hdrP); }










