// Revision: 8/28/2007
// To Build:
//   gcc ethernet.c frmdisp.c ipaddr.c lldp.c macaddr.c main.c -o lldp_parser

#include <stdio.h>
#include <stdlib.h>
#include <string.h> // used in LLDP.c - strlen()

#include "mytypes.h"

#include "frmdisp.h"
//#define FRAME_BUFFER 1518+4 // 384 with 4 bytes padding

char frame_buf[1500];
//volatile T_UINT32 RamBuf = (T_UINT32)frame_buf;
volatile unsigned long RamBuf = (unsigned long)frame_buf;

void hexdump( char *frame_buf, int frameSize )
{
  int k = 0;
  int x = 0;
  for ( k = 0; k < frameSize; k++ )
  {
    x = frame_buf[k] & 0xFF;
    printf( "%02x ", x );
    if ( (k+1) % 16 == 0 )
    {
      printf( "\n" );
    }
  }
  printf( "\n" );
}

int main(int argc, char *argv[])
{
  T_UINT16 frameSize = 0; // was 1500;
  FILE *pktfile = NULL;
  char c;

  pktfile = fopen( "sample.bin", "rb" );
  if ( pktfile == NULL )
  {
    fprintf( stderr, "error - missing file\n" );
    return 1;
  }

  while ( (c = fgetc(pktfile)) != EOF )
  {
    frame_buf[frameSize] = c;
    frameSize++;
    if ( frameSize > 1500 )
    {
      break;
    }
  }
  fclose( pktfile );

  fprintf( stderr, "DEBUG> frameSize= %d\n", frameSize );
  if ( frameSize > 4 )
  {
    frameSize -= 4;
  }
  //hexdump( frame_buf, frameSize );
//  return 0;

  FrmDisp_Dispatch_Linked(frameSize);
  
//  system("PAUSE");	
  fprintf( stderr, "DEBUG> done\n" );
  return 0;
}
