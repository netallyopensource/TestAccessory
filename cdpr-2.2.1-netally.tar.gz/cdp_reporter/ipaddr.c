// ********************************************************
//
// DESCRIPTION  IP Address Class
// Copyright (c) Fluke Corp, 1996-2007
//
// ********************************************************
#include <stdio.h>
#include <string.h>

#include "mytypes.h" 

#include "macaddr.h"
#include "ipaddr.h"


// Special IP addresses
// When the assignment operator ( = ) is used to fill Ip address the bytes and words
// must be swapped to work correctly with the little endianness of the Mitsibushi uP
T_IpAddr ipBcast =       0xffffffff;  // 255.255.255.255
T_IpAddr ipZero =        0x00000000;  // 000.000.000.000

// ip address has four binary bytes.  This is called the raw ip address
// as a string it looks like nnn.nnn.nnn.nnn for human readability

//
// Make a zero ip address
//
void IpAddr_Clear( T_IpAddr *address)
{
     *address = 0L;
}

//
//  fill a raw ip address from a buffer location
//  the code which does memcpy() for the Mitsibushi M3620 uP fails if the copy starts
//  on an odd byte boundary so this brute force method is used
//
void IpAddr_SetAddr(T_IpAddr *address, T_BYTE *buf)
{
    T_UINT8 i;
    T_BYTE *addr = (T_BYTE *)address; // temporary variable to keep from repeating the 
                                      // cast operation on address      
    for (i = 0; i < IP_ADDR_SIZE; ++i)
    {
        *addr++ = *buf++;
    }       
//    memcpy((T_BYTE *)address, buf, IP_ADDR_SIZE);   // long assigns on non byte boundaries causes problems
}           


//
//  fill a buffer from an ip address 
//  the code which does memcpy() for the Mitsibushi M3620 uP fails if the copy starts
//  on an odd byte boundary so this brute force method is used
//
void IpAddr_GetAddr(T_IpAddr *address, T_BYTE *buf)
{
    T_UINT8 i;
    T_BYTE *addr = (T_BYTE *)address;
    for (i = 0; i < IP_ADDR_SIZE; ++i)
    {
        *buf++ = *addr++;
    }       
//    memcpy(buf, (T_BYTE *)address, IP_ADDR_SIZE);   // long assigns on non byte boundaries causes problems
}   

//
//  sizeof T_IpAddr
//
T_UINT16 IpAddr_DataLen()
{
    return IP_ADDR_SIZE;
}
 
//
// Set the IP address given a string
// returns false if there is a failure
// 
// Nov 1, 2001 Thomas Doumas  Put in a check for string values greater than
//							  255. Force any bytes over 255 to 255.
//
T_BOOL IpAddr_Parse(T_IpAddr *address, T_BYTE *addrStr)
{
    T_UINT16 addr[IP_ADDR_SIZE];  // sscanf expects size int
    T_UINT8 *ip = (T_pBYTE)address;
    T_UINT16 num;
    T_UINT16 index;
    memset(addr, 0, IP_ADDR_SIZE * sizeof(unsigned));

//    num = sscanf(addrStr, "%d.%d.%d.%d", addr, addr + 1, addr + 2, addr + 3);
    num = sscanf((const char *)addrStr, "%d.%d.%d.%d", addr, addr + 1, addr + 2, addr + 3);

    for (index = 0; index < IP_ADDR_SIZE; index++)
    {
		// Here is the limit setting to 255.
        ip[index] = (addr[index] > 255) ? (T_UINT8) 255 : (T_UINT8) addr[index];
    }
    return (T_BOOL) (num == IP_ADDR_SIZE);
}

//
// convert a raw ip address to a string
// 
void IpAddr_Format(T_IpAddr *const address, T_BYTE *str)
{
    T_UINT8 *ip = (T_pBYTE)address;
    sprintf((char far*)str, "%03d.%03d.%03d.%03d", ip[0], ip[1], ip[2], ip[3]);
}


//
// see if the ip address is a broadcast address
//
T_BOOL IpAddr_IsBcast(T_IpAddr address)
{
    return (T_BOOL) (address == ipBcast);
}

//
// true if the ip address is a loop back address
//
T_BOOL IpAddr_IsLoopback(T_IpAddr address)
{
       // address starts with 127 ?
    if ((address & 0xFF000000) == 0x7f000000)
        return TRUE;
    else
        return FALSE;
}

//
// true if the ip address is empty
//
T_BOOL IpAddr_IsNull(T_IpAddr address)
{ 
    return (T_BOOL) (address == ipZero);
}



//
// Get IP address class
// 
T_IpClass IpAddr_IpClass(T_IpAddr address)
{
	T_UINT8   nclass;
	T_UINT8 temp = *((T_pBYTE) &address);

	for (nclass = CLASS_A; (temp & 0x80) && (nclass < CLASS_E); nclass++) 
	{
		temp = temp << 1;
	}

	return (T_IpClass) nclass;
}

//
// Returns the minimum valid mask for this class address.
// This is the closest we can come to generating a correct
// subnet mask guess.  It is really the network mask not
// the subnet mask
//
T_UINT32 IpAddr_MinValidMask(T_IpAddr address)
{
    T_UINT32 mask = 0UL;
	T_IpClass nclass = IpAddr_IpClass(address);
	T_UINT8 *maddr = (T_pBYTE) &mask;

	maddr[0] = 0xFF;
	if ((nclass >= CLASS_B) && (maddr[1] != 0xFF))
	{
		maddr[1] = 0xFF;
	}
	if ((nclass >= CLASS_C) && (maddr[2] != 0xFF))
	{
		maddr[2] = 0xFF;
	}

	return mask;
}
