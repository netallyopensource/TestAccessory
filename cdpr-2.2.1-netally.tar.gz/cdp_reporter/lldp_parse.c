// ********************************************************
//
// DESCRIPTION  Parse LDP frames (Link Layer Discovery Protocol)
// Copyright (c) Fluke Corp, 2006-2007
//
// ********************************************************

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "mytypes.h"

#include "lldp_parse.h"
#define MAX_FRAME_LENGTH 2048     
#define SIZEOF_TLV_HEADER  2 // 2 bytes


/////////////////////////////////////
// Link Layer Discovery Protocol methods
///////////////188
//////////////////////

static T_LLDPHeader *LLDP_hdrP;     // points to first TLV
static T_LLDPHeader *LLDP_curTlvP;  // the current TLV


void LLDP_SetHdrP(T_UINT8 *hdrp)
{
    LLDP_hdrP = (T_LLDPHeader *) hdrp;
}


T_UINT8 *LLDP_GetHdrP(void)
{
    return (T_UINT8 *)LLDP_hdrP;
}


//
// Return the start of data for the current TLV field
UINT8 *LLDP_GetDataPtr()
{
  UINT8 *data = NULL;

  if (LLDP_curTlvP)
  {
    data = (UINT8 *) LLDP_curTlvP + SIZEOF_TLV_HEADER; // sizeof(T_LLDPHeader);
  }

  return data;
}


//
// Return the data length for the current TLV field
UINT16 LLDP_GetDataLen()
{
  UINT16 length = 0;

  if (LLDP_curTlvP)
  {
    length = LLDP_GetLength();
    //printf("DEBUG> GetDataLen length=%hu\n", length);
  }

  return length;
}


//
// Return the string data for the current TLV field
T_BOOL LLDP_GetData(char *str, int size)
{
  int   i;
  char *buf;
  int   strLen;
  T_BOOL retval;
  //int byte = 0; // DEBUG only

  strLen = LLDP_GetDataLen();
  //printf("DEBUG> GetData() size=%d strLen=%d\n", size, strLen);

  if (strLen > 0)
  {

    // limit string length
    if (strLen > size)
      strLen = size;

    buf = (char*)LLDP_GetDataPtr();
    for (i = 0; i < strLen; ++i)
    {
      //byte = *buf;
      //byte = byte & 0xFF;
      //printf( "DEBUG> i=%d byte=0x%02x\n", i, byte );
      *str++ = *buf++;
    }
    *str = '\0';
    retval = TRUE;
  }
  else
  {
    *str = '\0';
    retval = FALSE;
  }

  return retval;
}


//
// Return the tag
UINT16 LLDP_GetTag()
{ 
	T_LLDPHeader*	_curTagTlv = LLDP_curTlvP;

	UINT16 retVal	= ((_curTagTlv->tag >> 1) & 0x7F);

	return (LLDP_curTlvP ? retVal : 0);
}


//
// return tlv data length
UINT16 LLDP_GetLength()						
{ 
    T_LLDPHeader*	_curLengthTlv = LLDP_curTlvP;
    UINT16 retVal	= 0;

    char *pByte = (char*)LLDP_curTlvP;
    int upperByte = *(pByte+0);
    int lowerByte = *(pByte+1);

    upperByte = upperByte & 0x01; // single bit
    lowerByte = lowerByte & 0xFF; // full byte

//    retVal = (T_UINT16)((T_UINT16)_curLengthTlv->tag & 0x01) << 8;
//    retVal |= _curLengthTlv->length;
    retVal = (upperByte << 8) | lowerByte;

    return (LLDP_curTlvP ? retVal : 0);
}

void LLDP_ResetCurrTlvPointer()
{
  LLDP_curTlvP = (T_LLDPHeader *) (LLDP_hdrP + TLV_OFFSET);
}

//
// Position the current TLV to the specified field
T_BOOL LLDP_FindTlv(TlvTagE tag, T_BOOL bContinued)
{
  UINT16 length;
  UINT16 index;

  if ( bContinued == FALSE )
  {
    // Reset the current TLV to the first one
    LLDP_curTlvP = (T_LLDPHeader *) (LLDP_hdrP + TLV_OFFSET);
  }
//printf( "LLDP_FindTlv() sizeof(T_LLDPHeader)=%d\n", sizeof(T_LLDPHeader) );

  // Find the specified field
  for (index = 0; (LLDP_GetTag() != TAG_END_OF_LLDP) && (index < MAX_FRAME_LENGTH); index++)
  {

    // Check for the specified tag
    if (tag == LLDP_GetTag())
    {
      return TRUE;
    }

    // Move to next field
    length = LLDP_GetLength();
    LLDP_curTlvP = (T_LLDPHeader *) ((UINT8 *) LLDP_curTlvP + length + SIZEOF_TLV_HEADER); //sizeof(T_LLDPHeader));
  }

  LLDP_curTlvP = NULL;
  return FALSE;
}

// Return the enabled capabilities of the device
T_BOOL LLDP_GetEnabledCapabilities(T_UINT16 *cap)
{
    T_BOOL bFound = FALSE;
    *cap = 0;
    UINT16 length;
    char *c;
    LLDP_ResetCurrTlvPointer();
    if ( LLDP_FindTlv(TAG_CAPABILITIES, FALSE) )
    {
        length = LLDP_GetDataLen();
        if (length == 4)
        {
            bFound = TRUE; 
            c = (T_BYTE*) LLDP_GetDataPtr();

            // Move past the caps to the enabled caps
            c += 2;

            // save the enbaled capabilities
            ((char*)cap)[0] = c[0];
            ((char*)cap)[1] = c[1];
        }
    }

    return bFound;
}


// Return the device name
T_BOOL LLDP_GetName(char *name, int size)
{
  T_BOOL bFound = FALSE;
  *name = '\0';
  if ( LLDP_FindTlv(TAG_SYSTEM_NAME, FALSE) )
  {
	LLDP_GetData(name, size);
	bFound = TRUE;
  }

  return bFound;
}


//
// Return the port string
T_BOOL LLDP_GetPort(char *port, int size)
{
    int i;

    // give preference to the optional Port Description, if it exists
    if ( LLDP_FindTlv(TAG_PORT_DESCR, FALSE) )
    {
        return LLDP_GetData(port, size);
    }

    // otherwise, use the mandatory Port ID string, which could be
    // the MAC address of the individual port, not the switch MAC
    if ( LLDP_FindTlv(TAG_PORT_ID, FALSE) )
    {
        //printf( "DEBUG> LLDP parsing Port ID: size= %d\n", size );
        if ( LLDP_GetData(port, size) ) // if string length > 0
        {
            //printf( "DEBUG> LLDP port[0]= %c\n", port[0] );
            // The first character is the ID subtype
            // Anything other than subtype 0 is okay. 0 is reserved.
            if ( port[0] != 0 )
            {
                if ( port[0] == 0x04 && port[1] == 0x01 ) // network IP address
                {
                    sprintf( port, "%03d.%03d.%03d.%03d", 
                        port[2], port[3], port[4], port[5] );
                }
                else // assume ASCII string representation for portId
                {
                    // skip first byte
                    for (i = 0; i < size; ++i)
                    {
                        *port = *(port+1);
                        ++port;
                    }
                    *port = '\0';
                }
                //return (strlen((const char*)port) > 0);
                if (strlen((const char*)port) > 0)
                    return TRUE;
                else
                    return FALSE;
            }
        }
    }

    *port = '\0';
    return FALSE;
}


//
// Return the source IP address
//
T_BOOL LLDP_GetSrcIp(T_UINT8 *ip, T_UINT8 size)
{
  int      i;
  char    *c;
  T_UINT8  expected[2] = {0x05, 0x01}; // expected String Length and IPv4 Subtype
  T_BOOL   retval = FALSE;

  if ( LLDP_FindTlv(TAG_MGMT_ADDRESS, FALSE) && (LLDP_GetDataLen() >= 6) )
  {
    c = (char*) LLDP_GetDataPtr();
	if ( memcmp( c, expected, 2 ) == 0 )
	{
      c += 2;
      for (i = 0; i < size; ++i)
        *ip++ = *c++;
      *ip = '\0';
      retval = TRUE;
	}
  }
  return retval;
}


//
// Return the switch MAC address
//
T_BOOL LLDP_GetSwitchMac(T_UINT8 *mac)
{
  int       i;
  char     *c;
  char      buf[6];
  UINT8     expectedSubtype = 0x04; // expected Chassis Subtype  
  T_BOOL    retval = FALSE;

  if ( LLDP_FindTlv(TAG_CHASSIS_ID, FALSE) && (LLDP_GetDataLen() == 7) )
  {
    c = (char*) LLDP_GetDataPtr();
	if ( *c == expectedSubtype )
	{
	    c += 1;
         for (i = 0; i < 6; ++i)
            buf[i] = *c++;
        // convert to a string
        sprintf((char *)mac, "%02x:%02x:%02x:%02x:%02x:%02x", 
          buf[0] & 0xFF, buf[1] & 0xFF, buf[2] & 0xFF, 
          buf[3] & 0xFF, buf[4] & 0xFF, buf[5] & 0xFF);
	    retval = TRUE;
	}
  }
  return retval;
}

#ifdef LLDP_DEBUG
//
// According to the SunOS man page, memcmp returns indeterminate sign
// depending on whether characters are signed or not.
//
int LLDP_memcmp( const char *a, const char *b, int n )
{
    for( ; n > 0; n--, a++, b++ )
	if( *a != *b )
		return 1;
	    //return (int)(*(FAR char*)a) - (int)(*(FAR char*)b);
    return 0;
}
#endif

//
// Return the optional VLAN ID
//
T_BOOL LLDP_GetVlanId(T_BYTE **pVlanId)
{
  T_BOOL retval = FALSE;
  T_BYTE *c;
  int expectedTLVlength = 6;
  int length = 0;
  T_BYTE orgCodeAndSubtype[] = {0x00, 0x80, 0xC2, 0x01}; // network byte order -- works with LLDP_memcmp()

  LLDP_ResetCurrTlvPointer();
  while ( LLDP_FindTlv(TAG_ORG_SPECIFIC, TRUE) ) // iterate thru multiple TAG_ORG_SPECIFIC fields
  {
        length = LLDP_GetDataLen();
        if ( length == expectedTLVlength )
        {
      c = (T_BYTE*) LLDP_GetDataPtr();
      //if ( LLDP_memcmp(c, orgCodeAndSubtype, 4) == 0 ) // works OK
      if ( memcmp((char far*)c, (char far*)orgCodeAndSubtype, 4) == 0 ) // (char far *) is required
      {
        // save VLAN ID for GUI and Reports
        c += 4;
        *pVlanId = c;
        retval = TRUE;
        break;
      }
        }

    // Move to next field
    //length = LLDP_GetLength();
    LLDP_curTlvP = (T_LLDPHeader *) ((UINT8 *) LLDP_curTlvP + length + SIZEOF_TLV_HEADER); //sizeof(T_LLDPHeader));
  }
  
  return retval;
}

//
// Return the optional VLAN ID
//
T_BOOL LLDP_GetVoiceTLV(T_BYTE **pVoiceTLV)
{
  T_BOOL retval = FALSE;
  T_BYTE *c;
  int expectedTLVlength = 8;
  int length = 0;
  T_BYTE orgCodeAndSubtype[] = {0x00, 0x12, 0xbb, 0x02}; // network byte order -- works with LLDP_memcmp()

  *pVoiceTLV = 0;
  
  LLDP_ResetCurrTlvPointer();
  while ( LLDP_FindTlv(TAG_ORG_SPECIFIC, TRUE) ) // iterate thru multiple TAG_ORG_SPECIFIC fields
  {
        length = LLDP_GetDataLen();
        if ( length == expectedTLVlength )
        {
      c = (T_BYTE*) LLDP_GetDataPtr();
      //if ( LLDP_memcmp(c, orgCodeAndSubtype, 4) == 0 ) // works OK
      if ( memcmp((char far*)c, (char far*)orgCodeAndSubtype, 4) == 0 ) // (char far *) is required
      {
          if (c[4] == 0x01) // Voice
          {
            // save VLAN ID for GUI and Reports
            c += 4;
            *pVoiceTLV = c;
            retval = TRUE;
            break;
          }
      }
        }

    // Move to next field
    //length = LLDP_GetLength();
    LLDP_curTlvP = (T_LLDPHeader *) ((UINT8 *) LLDP_curTlvP + length + SIZEOF_TLV_HEADER); //sizeof(T_LLDPHeader));
  }
  
  return retval;
}


