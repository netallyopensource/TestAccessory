// ********************************************************
//
// DESCRIPTION  Parse EDP frames
// Copyright (c) Fluke Corp, 2004-2007
//
// ********************************************************

#ifndef __EDP_PARSE_H__
#define __EDP_PARSE_H__


//
// EDP Types
//

enum 
{
    EDP_END_TYPE     = 0x9900,
	EDP_NAME_TYPE    = 0x9901,
	EDP_GENERAL_TYPE = 0x9902,
	EDP_VLAN_ID_TYPE = 0x9905,
};

enum
{
	EDP_DEVICE_ADDRESS_LENGTH = 6,
	EDP_NAME_LENGTH           = 256,
	EDP_TOS_LENGTH            = 16,
};

//
// EPD frame format
//
typedef struct
{
  T_UINT16  version;
  T_UINT16  total_length;
  T_UINT16  checksum;
  T_UINT16  seq_number;
  T_UINT16  address_filler;                             // assumed to be zero for all processing
  T_UINT8   device_address[EDP_DEVICE_ADDRESS_LENGTH];  // mac address

} T_EDPHeader;

typedef struct
{
	T_UINT16  end;            // EDP_END_TYPE
	T_UINT16  record_length;
} T_EDPEnd;


typedef struct
{
	T_UINT16  name;            // EDP_NAME_TYPE
	T_UINT16  record_length;
	T_UINT8   str[EDP_NAME_LENGTH];
} T_EDPName;


typedef struct
{
	T_UINT16  general;            // EDP_GENERAL_TYPE
	T_UINT16  record_length;
	T_UINT16  slot;
	T_UINT16  port;
	T_UINT32  tos_id;
	T_UINT32  hw_id;
	T_UINT32  sw_id;
	T_UINT8   remote_tos[EDP_TOS_LENGTH];
} T_EDPGeneral;

typedef struct
{
	T_UINT16  markerType;            // EDP_VLAN_ID_TYPE
	T_UINT16  nRecordLength;
	T_UINT16  flags; // and reserved1
	T_UINT16  nVlanId;
	T_UINT32  reserved2;
	T_UINT32  ipAddress;
	T_UINT8   name[50]; // name length limit unknown
} T_EDPVlanInfo;


// Access methods
void        EDP_SetHdrP(T_UINT8 *hdrp);
T_UINT8    *EDP_GetHdrP();
  

// These routines get specific types from the EDP message
T_BOOL   EDP_GetType(T_UINT16 type,  T_BYTE **value, int *pOffset);
T_BOOL   EDP_GetAddress(char **value);
T_BOOL   EDP_GetSlot(char **value);
T_BOOL   EDP_GetPort(char **value);
T_BOOL   EDP_GetVlan(char far *szVlanId);
T_BOOL   EDP_GetName(char **value);
T_BOOL   EDP_GetNameLength(T_UINT16 *value);

#endif // __EDP_H__
