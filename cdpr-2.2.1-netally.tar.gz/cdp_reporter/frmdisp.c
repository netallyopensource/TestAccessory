// ********************************************************
//
// DESCRIPTION  Frame dispatcher
// Copyright (c) Fluke Corp, 2001-2007
//
// ********************************************************

#include <stdio.h>
#include "mytypes.h" 
#include "macaddr.h"
#include "ipaddr.h"
#include "frmtype.h"
#include "ethernet.h"
#include "frmdisp.h"
#include "discovery.h"


#include "cdp_parse.h"
#include "lldp_parse.h"
#include "edp_parse.h"

#include <sys/file.h>

#define PARSE_CDP_ENABLED
#define PARSE_EDP_ENABLED
#define MAX_IP_STRING_CHARS 15

extern FILE *outfile;
extern int   decodedPkt;

volatile T_UINT32 RamBuf;


// used to parse frames of concern while linked
T_UINT16 FrmDisp_Dispatch_Linked(char *frameBuf, T_UINT16 frameSize) 
{                
    T_INT16 qtagVlanId = -1;
    T_UINT16 ethType = 0;

    RamBuf = (unsigned long)frameBuf;

    //printf( "DEBUG> frameSize= %d\n", frameSize );
    //hexdump( RamBuf, frameSize );

    //for (i = 0; i < 250; ++i)  // parse a single frame only
    { 
        // there is a frame to process
        // all frames must be processed because EDP is not multi- or broad- cast

        Ethernet_Parse((T_pBYTE)RamBuf, frameSize);  // setup ethernet model 
        qtagVlanId = Ethernet_GetQtagVlanId();

        // process the frame if it is an interesting one
        ethType = Ethernet_GetType();
//printf("KLL_DEBUG> ethType= %hu\n", ethType);
        //printf( "DEBUG> etherType= %04x\n", ethType );
        switch (Ethernet_GetType())
        {
            case LLDP_TYPE:
              printf( "EtherType: LLDP\n" );
              FrmDisp_ParseLLDP();
            break;

            case CISCO_CDP_TYPE:
              printf( "EtherType: CDP\n" );
#ifndef ORIGINAL_CDP_PARSER
#ifdef PARSE_CDP_ENABLED
              FrmDisp_ParseCDP(qtagVlanId);
#endif
#endif
            break;

            case EXTREME_EDP_TYPE:
              printf( "EtherType: EDP\n" );
#ifdef PARSE_EDP_ENABLED
              FrmDisp_ParseEDP();
#endif
            break;

#ifdef PARSE_EAPOL
            case  EPOL_TYPE:
			  rcv_ptr = Ethernet_GetdataP();
			  if( rcv_ptr[1] != EAPOL_TYPE_START ){
                FrmDisp_ParseEPOL();
			  }
            break;
#endif
        } 
                                   
    }   
    return ethType;
}

unsigned short getInt16( char *value )
{
  unsigned short tmpInt16 = 0;
  int upperByte = 0;
  int lowerByte = 0;

  upperByte = *value;
  upperByte = upperByte & 0xFF;

  lowerByte = *(value+1);
  lowerByte = lowerByte & 0xFF;

  tmpInt16 = (upperByte << 8) | lowerByte; 

  return tmpInt16;
}

unsigned int getInt32( char *value )
{
    return (UINT32) value[0] << 24
         | (UINT32) value[1] << 16
         | (UINT32) value[2] << 8
         | (UINT32) value[3];
}

#ifdef PARSE_CDP_ENABLED
#define CDP_HOST 0x00000010

//
// Parses CPD portion of packet for protocol type and dispatches on that type 
//
void FrmDisp_ParseCDP(int qtagVlanId)
{
    char deviceId[MAX_DP_ID_LENGTH+1];
    char  address[MAX_DP_ID_LENGTH+1];
    char portId[MAX_DP_ID_LENGTH+1];
    char  platformId[MAX_DP_ID_LENGTH+1];
    char  vlanId[MAX_DP_ID_LENGTH+1];
    char *value;
    unsigned int capabilities = 0;
    int vlanInt = -1;
    int voipInt = -1;
    int elementLength = 0;

    deviceId[0] = '\0';
    address[0] = '\0';
    portId[0] = '\0';
    platformId[0] = '\0';
    vlanId[0] = '\0';

    CDP_SetHdrP( Ethernet_GetdataP() );

    elementLength = CDP_GetType(CDP_CAPABILITIES, &value);
    if (elementLength == 4)
    {
        capabilities = getInt32(value);
        if ((capabilities & CDP_HOST) != 0)
        {
            // We don't care about hosts, not our nearest switch
            printf( "Dropping host CDP: capabilities=0x%08x\n", capabilities);
            return;
        }
    }

    decodedPkt = 1;

    if ( outfile ) 
      fprintf(outfile, "EtherType: CDP\n" );

    elementLength = CDP_GetType(CDP_DEVICE_ID_TYPE, &value);
/*
    if (elementLength > MAX_DP_ID_LENGTH-1)
    {
        elementLength = MAX_DP_ID_LENGTH-1;
    }
*/
    if (elementLength > 0)
    {
        strncpy(deviceId, value, elementLength);
        deviceId[elementLength] = '\0';
    }
    
    
    if (CDP_GetType(CDP_ADDRESS_TYPE, &value))
    {
        // find address string
        if (CDP_GetAddress((T_UINT8*)(value+4), ((*(value+2) << 8) | *(value+3)), &value))
        {
            // convert address to a string
            IpAddr_Format((T_IpAddr*)value, address);
            address[MAX_DP_ID_LENGTH] = '\0';
        }
    }

    elementLength = CDP_GetType(CDP_PORT_ID_TYPE, &value);
    if (elementLength > 0)
    {
        strncpy(portId, value, elementLength);
        portId[elementLength] = '\0';
    }
    
    elementLength = CDP_GetType(CDP_PLATFORM_TYPE, &value);
    if (elementLength > 0)
    {
        strncpy(platformId, value, elementLength);
        platformId[elementLength] = '\0';
    }
    
    if (CDP_GetType(CDP_NATIVE_VLAN_ID_TYPE, &value))
    {
        vlanInt = getInt16(value);
    }

    if (CDP_GetType(CDP_VOIP_VLAN_ID_TYPE, &value))
    {
        value++; // advance one byte
        voipInt = getInt16(value);
    }
    
    if ( vlanInt >= 0 )
    {
        // "VLAN4096 VOIP4096" // 17 characters
    	if ( voipInt >= 0 )
    	{
            sprintf( (char far*)vlanId, "VLAN%04d VOIP%04d", vlanInt, voipInt );
        }
        else
        {
            sprintf( (char far*)vlanId, "VLAN%04d", vlanInt );
        }
    }
    else if ( voipInt >= 0 )
    {
        sprintf( (char far*)vlanId, "VOIP%04d", voipInt );
    }

    // print CDP frame summary info here
    printf( "Device ID: %s\n", deviceId );
    printf( "Addresses: %s\n", address );
    printf( "Platform:  %s\n", platformId );
    printf( "Port ID:   %s\n", portId );
    printf( "Vlan ID:   %s\n", vlanId );
    if ( outfile )
    {
      fprintf(outfile, "Device ID: %s\n", deviceId );
      fprintf(outfile, "Addresses: %s\n", address );
      fprintf(outfile, "Platform:  %s\n", platformId );
      fprintf(outfile, "Port ID:   %s\n", portId );
      fprintf(outfile, "Vlan ID:   %s\n", vlanId );

      // First one wins, could be improved!
      fflush(outfile);
      fclose(outfile);
      outfile = NULL;
    }

    if (voipInt > -1)
    {
        // TRL: No L2 priority provided by CDP as far as I can find ???
        configCdpVoiceVlan(voipInt);
    }
}

void configCdpVoiceVlan(unsigned int id)
{
    char cmd[512];

    int lock = open("/var/run/voip.lock", O_CREAT, S_IRUSR|S_IWUSR);
    if (lock >= 0)
    {
        flock(lock, LOCK_EX);
    }

    sprintf(cmd, "rm -rf /var/run/voip/cdp");
    system(cmd);
    sprintf(cmd, "mkdir -p /var/run/voip/cdp");
    system(cmd);

    sprintf(cmd, "echo \"%d\" > /var/run/voip/cdp/vlanid", id);
    system(cmd);

    if (lock >= 0)
    {
        flock(lock, LOCK_UN);
        close(lock);
    }
}
#endif

#ifdef PARSE_EDP_ENABLED
//
// Parses EDP portion of packet for protocol type and dispatches on that type 
//
void FrmDisp_ParseEDP()
{
    char *deviceId;
    char  address[MAX_DP_ID_LENGTH+1];
    char  portId[MAX_DP_ID_LENGTH+1];
    char  vlanId[MAX_DP_ID_LENGTH+1];
    char *value;
    T_UINT16 slot = 0;
    T_UINT16 port = 0;

    deviceId = NULL;
    address[0] = '\0';
    portId[0] = '\0';
    vlanId[0] = '\0';


    EDP_SetHdrP( Ethernet_GetdataP() );

    // get the name
    if (EDP_GetName(&value))
        deviceId = value;
    
    
    // find address string
    if (EDP_GetAddress(&value))
    {
        // convert address to a MAC address string
//      MacAddr_Format((T_MacAddr)value, address);
        sprintf((char far *)address, "%02x:%02x:%02x:%02x:%02x:%02x", 
            *(value+0) & 0xFF, *(value+1) & 0xFF, *(value+2) & 0xFF, 
            *(value+3) & 0xFF, *(value+4) & 0xFF, *(value+5) & 0xFF );
        address[MAX_DP_ID_LENGTH] = '\0';
    }
    
    // get slot and port
    if (EDP_GetSlot(&value))
    {
        slot = getInt16(value);
        slot++;
    }

    if (EDP_GetPort(&value))
    {
        port = getInt16(value);
        port++;
    }

	if ( slot != 0 && port != 0 )
	{
    	// format the slot and port 
    	sprintf((char far *)portId, "%d/%d", slot, port);
    }

    if ( EDP_GetVlan(vlanId) )
    {
        // do nothing - string already in correct format
    }

    // add the data to the device list
    if ((deviceId   != NULL)  &&
        (address[0] != '\0')  &&
        (portId[0]  != '\0')) // Skip VLAN ID (not available in EDP ??)
    {
//        Discovery_AddDevice((char far *)deviceId, (char far*)address, (char far *)portId, (char far *)vlanId, DP_EDP_TYPE);
    }

	// macAddr and vlanId
    if ((address[0] != '\0')  &&
        (vlanId[0]  != '\0'))
    {
//        Discovery_AddDevice((char far *)deviceId, (char far*)address, (char far *)portId, (char far *)vlanId, DP_EDP_TYPE);
    }

    // print EDP frame summary info here
    if (deviceId != NULL) // found optional device ID element
    {
        printf( "Device ID: %s\n", deviceId );
    }
    else
    {
        printf( "Device ID:   \n" ); // blank placeholder
    }
    printf( "Addresses: %s\n", address );
    printf( "Port ID:   %s\n", portId );
    printf( "Vlan ID:   %s\n", vlanId );
}
#endif

//
// Parses LLDP portion of packet for protocol type and dispatches on that type 
//
void FrmDisp_ParseLLDP()
{
    char deviceId[MAX_DP_ID_LENGTH+1];
    char address[MAX_DP_ID_LENGTH+1];
    char portId[MAX_DP_ID_LENGTH+1];
    char vlanId[MAX_DP_ID_LENGTH+1];
    char voiceTlv[MAX_DP_ID_LENGTH+1];
    T_UINT16 capabilities = 0;
    T_BYTE *value;
    int vlanInt = -1;
    int voice = 0;
    unsigned int voiceInt = 0;
    unsigned int voiceVlanId = 0;
    unsigned int voicePriL2 = 0;
    unsigned int voicePriL3 = 0;
    T_BYTE mgmtIp[4] = { 0x00 };

    deviceId[0] = '\0';
    address[0] = '\0';
    portId[0] = '\0';
    vlanId[0] = '\0';
    voiceTlv[0] = '\0';

    LLDP_SetHdrP( (T_UINT8*)Ethernet_GetdataP() );

    if (LLDP_GetEnabledCapabilities(&capabilities))
    {
        // Unfortunately not all switches send their caps so we just have to use it
        // if they don't
        capabilities = getInt16(&capabilities);
        if ((capabilities & (LLDP_CAP_REPEATER|LLDP_CAP_BRIDGE|LLDP_CAP_WAP|LLDP_CAP_ROUTER)) == 0)
        {
            // We don't care about hosts, not our nearest switch
            printf( "Dropping host LLDP: capabilities=0x%04x\n", capabilities);
            return;
        }
    }

    decodedPkt = 1;

    if ( outfile )
      fprintf(outfile, "EtherType: LLDP\n" );

    LLDP_GetName(deviceId, sizeof(deviceId));       // optional
    LLDP_GetSwitchMac(address);                     // mandatory
    LLDP_GetPort(portId, sizeof(portId));           // mandatory

    if ( LLDP_GetSrcIp(mgmtIp, sizeof(mgmtIp)) )
    {
        // convert address to a string in dotted decimal notation 
        IpAddr_Format((T_IpAddr*)mgmtIp, address);
        address[MAX_IP_STRING_CHARS] = '\0';
    }

    //LLDP_GetVlanId(vlanId, sizeof(vlanId));         // optional
    if ( LLDP_GetVlanId(&value) ) // optional
    {
        vlanInt = getInt16(value);
    }

    if ( vlanInt >= 0 )
    {
        // "VLAN4096 VOIP4096" // 17 characters
        sprintf( vlanId, "VLAN%04d", vlanInt );
    }
    
    if ( LLDP_GetVoiceTLV(&value) ) // optional
    {
        // Four bytes:
        // 1 byte application type
        // 0... .... .... .... .... .... = Policy: Defined
        // .1.. .... .... .... .... .... = Tagged: Yes
        // ...0 0000 1100 100. .... .... = VLAN Id: 100     
        // .... .... .... ...1 10.. .... = L2 Priority: 6
        // .... .... .... .... ..00 0000 = DSCP Priority: 0        
        //sprintf( voiceTlv, "%02x %02x %02x %02x", value[0], value[1], value[2], value[3] );
        if ( (value[1] & 0x40) != 0 )
        {
            voice = 1;
            voiceInt = getInt32(value);
            
            voiceVlanId = (voiceInt >> 9) & 0x00000fff;           
            voicePriL2  = (voiceInt >> 6) & 0x00000007;
            voicePriL3  =  voiceInt       & 0x0000003f;            
        }
    }
    
    // check for mandatory entries (deviceId and vlanId are for Cisco CDP)
    //if ((address[0] != '\0')  &&
    //    (portId     != NULL))
    {
        // print LLDP frame summary info here
        printf( "Device ID:           %s\n", deviceId );
        printf( "Addresses:           %s\n", address );
        printf( "Port ID:             %s\n", portId );
        printf( "Vlan ID:             %s\n", vlanId );
        if (voice)
        {
            printf( "Voice VLAN ID:       %d\n", voiceVlanId );
            printf( "Voice L2 Priority:   %d\n", voicePriL2 );
            printf( "Voice DSCP Priority: %d\n", voicePriL3 );
        }
        if ( outfile )
        {
          fprintf(outfile, "Device ID:           %s\n", deviceId );
          fprintf(outfile, "Addresses:           %s\n", address );
          fprintf(outfile, "Port ID:             %s\n", portId );
          fprintf(outfile, "Vlan ID:             %s\n", vlanId );
          if (voice)
          {
              fprintf(outfile, "Voice Vlan ID:       %d\n", voiceVlanId );
              fprintf(outfile, "Voice L2 Priority:   %d\n", voicePriL2 );
              fprintf(outfile, "Voice DSCP Priority: %d\n", voicePriL3 );
          }

          // First one wins, could be improved!
          fflush(outfile);
          fclose(outfile);
          outfile = NULL;
        }
    }
    
    if (voice)
    {
        configLldpVoiceVlan(voiceVlanId, voicePriL2, voicePriL3);
    }
}

void configLldpVoiceVlan(unsigned int id, unsigned int l2_pri, unsigned int l3_pri)
{
    char cmd[512];

    int lock = open("/var/run/voip.lock", O_CREAT, S_IRUSR|S_IWUSR);
    if (lock >= 0)
    {
        flock(lock, LOCK_EX);
    }

    sprintf(cmd, "rm -rf /var/run/voip/lldp");
    system(cmd);
    sprintf(cmd, "mkdir -p /var/run/voip/lldp");
    system(cmd);
    sprintf(cmd, "echo \"%d\" > /var/run/voip/lldp/vlanid", id);
    system(cmd);
    sprintf(cmd, "echo \"%d\" > /var/run/voip/lldp/priority", l2_pri);
    system(cmd);
    sprintf(cmd, "echo \"%d\" > /var/run/voip/lldp/dscp", l3_pri);
    system(cmd);

    if (lock >= 0)
    {
        flock(lock, LOCK_UN);
        close(lock);
    }
}
