// ********************************************************
//
// DESCRIPTION  Parse CDP frames
// Copyright (c) Fluke Corp, 2004-2007
//
// ********************************************************

#ifndef __CDP_PARSE_H__
#define __CDP_PARSE_H__

// All the data required by LinkRunner is defined in the version 1 CDP packet;
// version 2 packets add more data types.  LinkRunner only defines the required
// data types.


//
// CDP version numbers
//
enum 
{
    CDP_VERSION1 = 0x01,
    CDP_VERSION2 = 0x02,
};


//
// CDP Types
//
enum 
{
    CDP_DEVICE_ID_TYPE = 0x0001,
	CDP_ADDRESS_TYPE   = 0x0002,
	CDP_PORT_ID_TYPE   = 0x0003,
    CDP_CAPABILITIES   = 0x0004,
	CDP_PLATFORM_TYPE   = 0x0006,
	CDP_NATIVE_VLAN_ID_TYPE = 0x000A,
	CDP_VOIP_VLAN_ID_TYPE   = 0x000E,
};

// address related
enum
{
	CPD_ADDRESS_PROTOCOL_NLPID = 1,
	CPD_ADDRESS_PROTOCOL_802_2 = 2,
	CPD_ADDRESS_PROTOCOL_TYPE = 0xCC,
};


//
// CPD frame format
//
typedef struct
{
  T_UINT8   version;                    // version 1 or 2
  T_UINT8   ttl;                        // time to live
  T_UINT16  checksum;                   // IP checksum
// start of variable length data fields (repeat for rest of packet), of the form
  T_UINT16  type;                       // from types above
  T_UINT16  length;                     // type, length, and value field byte count
  void     *value;                      // variable length value field for this type
} T_CDPHeader;



// Access methods
void        CDP_SetHdrP(T_UINT8 *hdrp);
T_UINT8    *CDP_GetHdrP();

//
// Get values from a CDP frame
//
T_UINT8   CDP_GetVersion(void);                 
T_UINT8   CDP_GetTTL(void);                 
T_UINT16  CDP_GetChecksum(void);                  

// These routines get specific types from the CDP message
int CDP_GetType(T_UINT16 type,  char **value); // return >0 if type is found
T_BOOL   CDP_GetAddress(T_BYTE *ptr, T_UINT16 packet_length, char **value);  // call after address type found

#endif // __CDP_H__
