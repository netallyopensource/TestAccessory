/*
 * Copyright (c) 2013, Compulab Inc.
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */
#ifndef SCF0403_LCD_H_
#define SCF0403_LCD_H_

int scf0403_init(int reset_gpio);

#endif
