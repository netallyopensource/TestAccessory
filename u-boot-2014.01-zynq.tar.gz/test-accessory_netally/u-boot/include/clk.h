#ifndef _CLK_H_
#define _CLK_H_

int soc_clk_dump(void);

#endif /* _CLK_H_ */
