/*
 * (C) Copyright 2013 Faraday Technology
 * Dante Su <dantesu@faraday-tech.com>
 *
 * SPDX-License-Identifier:    GPL-2.0+
 */

#ifndef __FTSDC021_H
#define __FTSDC021_H

int ftsdc021_sdhci_init(u32 regbase);

#endif /* __FTSDC021_H */
